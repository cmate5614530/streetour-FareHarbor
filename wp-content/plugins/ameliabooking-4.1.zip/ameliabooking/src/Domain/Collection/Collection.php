<?php

namespace AmeliaBooking\Domain\Collection;

/**
 * Class Collection
 *
 * @package AmeliaBooking\Domain\Collection
 */
class Collection extends AbstractCollection
{

}
