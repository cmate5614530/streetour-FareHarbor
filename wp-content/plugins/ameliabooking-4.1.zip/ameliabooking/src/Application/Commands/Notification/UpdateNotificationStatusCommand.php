<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateNotificationStatusCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class UpdateNotificationStatusCommand extends Command
{

}
