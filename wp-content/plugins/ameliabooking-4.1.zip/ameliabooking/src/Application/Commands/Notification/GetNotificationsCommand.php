<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetNotificationsCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class GetNotificationsCommand extends Command
{

}
