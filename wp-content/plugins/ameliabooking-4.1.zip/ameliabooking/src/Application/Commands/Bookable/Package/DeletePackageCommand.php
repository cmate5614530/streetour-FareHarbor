<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Bookable\Package;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeletePackageCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Package
 */
class DeletePackageCommand extends Command
{

}
