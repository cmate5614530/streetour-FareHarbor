<?php

namespace AmeliaBooking\Application\Commands\Bookable\Extra;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateExtraCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Extra
 */
class UpdateExtraCommand extends Command
{

}
