<?php

namespace AmeliaBooking\Application\Commands\Booking\Appointment;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class CancelBookingRemotelyCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Appointment
 */
class CancelBookingRemotelyCommand extends Command
{

}
