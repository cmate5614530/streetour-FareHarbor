<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="bookly-box">
    <select class="bookly-js-time-zone-switcher bookly-time-zone-switcher">
        <?php echo $time_zone_options ?>
    </select>
</div>