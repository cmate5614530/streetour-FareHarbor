<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<th><?php esc_html_e( get_option( 'bookly_l10n_info_address' ), 'bookly' ) ?></th>