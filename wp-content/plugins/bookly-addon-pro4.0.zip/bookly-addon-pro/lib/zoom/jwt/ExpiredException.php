<?php
namespace BooklyPro\Lib\Zoom\Jwt;

class ExpiredException extends \UnexpectedValueException
{
}
