"use strict";
$(document).ready(function() {
	var elemsmall = document.querySelector('.js-small');
	var switchery = new Switchery(elemsmall, { color: '#1abc9c', jackColor: '#fff', size: 'small' });
});