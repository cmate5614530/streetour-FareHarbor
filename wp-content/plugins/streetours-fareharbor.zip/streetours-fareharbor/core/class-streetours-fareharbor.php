<?php
class Streetours_Fareharbor {

	public static function init() {
		
	}
}
Streetours_Fareharbor::init();
