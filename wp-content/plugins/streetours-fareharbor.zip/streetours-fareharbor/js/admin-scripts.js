jQuery(document).ready(
	function($) {
});
